# CafePOS.Api — Standalone Export

This is the backend API project only (ASP.NET Core 9 / EF Core / Npgsql), exported without secrets or build artifacts.

## What's excluded (on purpose)

- `appsettings.Development.json` — this held the real Supabase DB connection string, Gmail app password, and Gemini API key. Never shipped in an archive.
- `keys/` — Data Protection keys used to encrypt/decrypt QR ordering tokens. Regenerate on the new host; existing printed QR codes will need reprinting if you copy this project to a new server without also copying these.
- `bin/` / `obj/` — build output, regenerated automatically on first build.

## To run this on a new host

1. Restore packages: `dotnet restore`
2. Provide your own secrets, either via:
   - a local `appsettings.Development.json` (same shape as `appsettings.json`, with real values for `ConnectionStrings:CafePos`, `Jwt:Secret`, `Email:GmailAddress`/`GmailAppPassword`, `Gemini:ApiKey`), or
   - environment variables (e.g. `ConnectionStrings__CafePos`, `Jwt__Secret`, etc. — ASP.NET Core's standard `__` env-var override convention)
3. `dotnet ef database update` to apply migrations against your Postgres instance (or let the app run its own startup migration — check `Program.cs`).
4. `dotnet run` (dev) or `dotnet publish` for a production build.

## Requirements

- .NET 9 SDK
- A Postgres database (the app is written against Npgsql/Postgres specifically — the schema and migrations assume Postgres, not SQL Server or MySQL)
