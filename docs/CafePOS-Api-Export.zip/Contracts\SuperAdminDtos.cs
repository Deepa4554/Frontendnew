using CafePOS.Api.Domain;

namespace CafePOS.Api.Contracts;

public record TenantSummaryDto(
    int Id, string Name, string Slug, string Status, DateTime CreatedAt,
    string Plan, DateTime? PlanExpiresAt, int StaffCount, int BranchCount)
{
    public static TenantSummaryDto From(Tenant t, Subscription? sub, int staffCount, int branchCount) => new(
        t.Id, t.Name, t.Slug, t.Status.ToString().ToUpperInvariant(), t.CreatedAt,
        sub?.Plan.ToString().ToUpperInvariant() ?? "NONE", sub?.PlanExpiresAt, staffCount, branchCount);
}

public record AdminChangePlanRequest(SubscriptionTier Plan);

public record DailySalesDto(string Date, decimal Revenue, int OrderCount);
public record MonthlySalesDto(string Month, decimal Revenue, int OrderCount);

public record TenantSalesDto(
    int TenantId,
    string TenantName,
    decimal TodayRevenue,
    decimal ThisMonthRevenue,
    decimal AllTimeRevenue,
    int AllTimeOrderCount,
    List<DailySalesDto> Daily,
    List<MonthlySalesDto> Monthly);
